package ar.org.centro8.java.curso.entidades.relaciones;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NonNull;

@Data
@AllArgsConstructor
public class EmpleadoComposicion {
    /*
     * Las composiciones son de las relaciones más fuertes entre clases.
     * Una clase no tiene sentido sin el objeto de la otra clase que lo compone.
     * La reconocemos con las palabras "siempre tiene un/a".
     * En este caso, un empleado siempre tiene un auto.
     */

    private int legajo;
    private String nombre;
    private String apellido;
    @NonNull //anotación de Lombok para indicar que el atributo no puede ser nulo
    private Auto auto;
    //si se quisiera ingresar un auto nulo, dará error en tiempo de ejecución.
    //De esta manera nos aseguramos de que un empleado, siempre tenga un auto

    //un ejemplo de composición aún más fuerte es crear el objeto de Auto dentro del
    //mismo constructor de Empleado
    /**
     * Constructor que recibe los parámetros para crear un nuevo auto
     * @param legajo
     * @param nombre
     * @param apellido
     * @param marca
     * @param modelo
     * @param color
     */
    public EmpleadoComposicion(int legajo, String nombre, String apellido, String marca,
                                String modelo, String color) {
        this.legajo = legajo;
        this.nombre = nombre;
        this.apellido = apellido;
        this.auto = new Auto(marca, modelo, color);
    }

    //con el setAuto() podemos cambiar el auto.    

}
