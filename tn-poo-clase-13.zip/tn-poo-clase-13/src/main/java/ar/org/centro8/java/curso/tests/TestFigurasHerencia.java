package ar.org.centro8.java.curso.tests;

import ar.org.centro8.java.curso.ejercicios.figuras.herencia.Circulo;
import ar.org.centro8.java.curso.ejercicios.figuras.herencia.Figura;
import ar.org.centro8.java.curso.ejercicios.figuras.herencia.Rectangulo;
import ar.org.centro8.java.curso.ejercicios.figuras.herencia.TrianguloRectangulo;

public class TestFigurasHerencia {
    public static void main(String[] args) {
        Figura figura1 = new Rectangulo(12, 35);
        System.out.println(figura1);
        System.out.println(figura1.getPerimetro());
        System.out.println(figura1.getSuperficie());

        figura1 = new TrianguloRectangulo(15,65);
        System.out.println(figura1);
        System.out.println(figura1.getPerimetro());
        System.out.println(figura1.getSuperficie());

        figura1 = new Circulo(12);
        System.out.println(figura1);
        System.out.println(figura1.getPerimetro());
        System.out.println(figura1.getSuperficie());
    }
}
