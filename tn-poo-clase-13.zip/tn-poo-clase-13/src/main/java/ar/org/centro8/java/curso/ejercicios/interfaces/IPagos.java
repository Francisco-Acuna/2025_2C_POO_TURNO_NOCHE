package ar.org.centro8.java.curso.ejercicios.interfaces;

public interface IPagos {
    //definimos el contrato que puede servir para cualquier clase que lo implemente.
    //Cada clase deberá definir el comportamiento y la tecnología que se necesite para implementar
    //cada método.
    void pagarConTarjetaDebito(double monto);
    void pagarConTarjetaCredito(double monto);
    void pagarConTransferencia(double monto);
    void pagarConEfectivo(double monto);
    void pagarConQR(double monto);

    /**
     * Método para retornar el monto redondeado a 2 decimales
     * @param monto -> es el monto a redondear
     * @return -> monto redondeado a 2 decimales
     */
    default double montoFormateado(double monto){
        return Math.round(monto * 100.0) / 100.0;
        // monto -> 123.45678
        // * 100.0 -> 12345.678
        // round() redondea al entero más cercano
        // si el decimal que sigue es mayor o igual a 5, pasa al entero siguiente
        // si el decimal que sigue es menor que 5, queda en el entero que está
        // round() -> 12346
        // / 100.0 -> 123.46
        // monto redondeado es -> 123.46
    }

    /**
     * Método que retorna el resultado de aplicar un descuento al monto ingresado
     * @param monto -> monto al que se le aplicará el descuento
     * @param descuento -> porcentaje de descuento a aplicar
     * @return -> monto con el descuento aplicado.
     */
    default double aplicarDescuento(double monto, double descuento){
        return monto - (monto / 100.0 * descuento);
    }

    /**
     * Método que retorna el resultado de aplicar un recargo al monto ingresado
     * @param monto -> monto al que se le aplicará el recargo
     * @param recargo -> porcentaje de recargo a aplicar
     * @return -> monto con el recargo aplicado.
     */
    default double aplicarRecargo(double monto, double recargo){
        return monto + (monto / 100.0 * recargo);
    }
}
