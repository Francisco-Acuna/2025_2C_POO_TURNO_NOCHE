package ar.org.centro8.java.curso.tests;

import ar.org.centro8.java.curso.entidades.objetos.Dato;
import ar.org.centro8.java.curso.entidades.relaciones.Cuenta;
import ar.org.centro8.java.curso.entidades.relaciones.herencia.ClientePersona;
import ar.org.centro8.java.curso.entidades.relaciones.herencia.Direccion;
import ar.org.centro8.java.curso.entidades.relaciones.herencia.Empleado;
import ar.org.centro8.java.curso.entidades.relaciones.herencia.Persona;

public class TestObjetosYCadenas {
    public static void main(String[] args) {
        /*
         * En Java existe la clase Class, internamente se toma a todas las clases que nosotros
         * creamos, como objetos de la clase Class en tiempo de ejecución.
         * Los atributos, son tratados en Java como objetos de la clase Field, que se encuentra
         * en el paquete java.lang.reflect.Field
         * Los métodos son tratados internamente por Java como objetos de la clase Method
         * que se encuentra en el paquete java.lang.reflect.Method
         * Aunque nosotros no creemos objetos de Field ni de Method directamente, el compilador
         * y la JVM generan estos objetos internamente para gestionar la información de nuestras
         * clases.
         * Las clases públicas de java.lang son accesibles de manera global
         */

        Direccion direccion1 = new Direccion("Av. Medrano", 162, "2", "8");
        Cuenta cuenta1 = new Cuenta(1, "Pesos argentinos");
        Persona persona1 = new Empleado("Mario", "Barakus", 90, direccion1, 100, 1_500_000);
        System.out.println(persona1);
        Persona persona2 = new ClientePersona("Juan", "Cito", 20, direccion1, 100, cuenta1);
        System.out.println(persona2);

        // Empleado empleado1 = persona1;
        //error porque la variable está guardado dentro de un contenedor mayor que es Persona
        //lo que podemos hacer es castear la asignación
        //castear es Java significa cambiar el tipo de dato
        //Es una forma de indicarle al compilador que trate al objeto como si fuera de otro tipo
        // Empleado empleado1 = (Empleado) persona2;
        //con el casteo le avisamos al compilador que le estamos pasando un objeto del tipo Empleado
        //si le pasamos otro tipo de dato, Java lo va a intentar guardar igual, pero va a arrojar
        //una ClassCastException que detendrá el programa.
        Empleado empleado1 = (persona1 instanceof Empleado) ? (Empleado) persona1 : null;
        System.out.println(empleado1);

        //los objetos tienen acceso a todos sus miembros más todo lo heredado de la clase padre
        //y de la clase Object (clase padre de todas las clases).
        //El objeto de una clase padre no tiene acceso a los miembros de sus clases hijas

        System.out.println();

        Dato d1 = new Dato(2);
        Dato d2 = d1;
        Dato d3 = new Dato(d1.dato);
        Dato d4 = new Dato(4);
        String st = "2";

        //el método hashCode() es un método de la clase Object
        //El código hash es un valor entero calculado por Java a partir del estado o identidad del
        //objeto. Este valor se utiliza principalmente en estructuras que realizan búsquedas o
        //almacenamiento eficiente. No es el lugar en memoria.
        System.out.println("d1.hashCode():" + d1.hashCode()); //214126413 - 33
        System.out.println("d2.hashCode():" + d2.hashCode()); //214126413 - 33
        System.out.println("d3.hashCode():" + d3.hashCode()); //769287236 - 33
        System.out.println("d4.hashCode():" + d4.hashCode()); //1587487668 - 35
        System.out.println("st.hashCode():" + st.hashCode()); //50 - 50
        //vemos que d1 y d2 tienen el mismo hashCode porque son considerados el mismo objeto.
        System.out.println();
        //el método equals() también está definido en la clase Object
        //compara objetos por medio del código hash
        System.out.println("d1.equals(d1):" + d1.equals(d1)); //true - true
        System.out.println("d1.equals(d2):" + d1.equals(d2)); //true - true
        System.out.println("d1.equals(d3):" + d1.equals(d3)); //false - true
        System.out.println("d1.equals(d4):" + d1.equals(d4)); //false - false
        System.out.println("d1.equals(st):" + d1.equals(st)); //false - false

        //puede darse la situación en que debamos tomar en cuenta dos objetos como iguales
        //cuando compartan el mismo estado. 
        //Para hacer eso, es necesario sobreescribir los métodos .equals() y hashCode()


        ////////////////////////////////////////////////////////////////////////////
        
        System.out.println("** Clase String **");

        //podemos crear un objeto de la clase String de varias formas
        String texto1 = "Cadena de Texto!";
        String texto2 = new String("Hola");
        String texto3 = "hola";

        //métodos para comparar
        //al comparar con el operador == se va a comparar que sean el mismo objeto en memoria
        System.out.println(texto2 == "Hola"); //false
        //hay una oportunidad en que la comparación podría darnos true
        System.out.println(texto3 == "hola"); //true
        //esto sucede porque internamente se da un comportamiento especial denominado "intering"
        //las cadenas se guardan en un mismo pool de cadenas para ahorrar memoria cuando son
        //creadas con las comillas dobles. Es decir, que de manera interna estarían ocupando el
        //mismo lugar de memoria y por eso se las consideran iguales.
        //Comparar contenidos de cadenas con el operador == no brinda un comportamiento garantizado

        //Para comparar cadenas de caracteres teniendo en cuenta su contenido, se utilizan
        // .equals() .equalsIgnoreCase()
        System.out.println(texto2.equals("hola")); //false
        System.out.println(texto2.equalsIgnoreCase("hola")); //true

        //Pasar a minúsculas y mayúsculas
        // .toLowerCase() .toUpperCase()
        System.out.println(texto2.toLowerCase()); // hola
        System.out.println(texto2.toUpperCase()); // HOLA

        // .contains()
        //devuelve un booleano que indica si contiene la subcadena pasada como parámetro
        System.out.println(texto1.contains("hola")); //false
        System.out.println(texto2.contains("ola")); //true

        // .length()
        //devuelve la longitud de la cadena. Es decir, la cantidad de caracteres que tiene.
        System.out.println(texto1.length()); //16
        System.out.println(texto2.length()); //4

        // .isEmpty()
        // indica si la cadena está vacía, evaluando si la longitud es igual a 0
        System.out.println(texto1.isEmpty()); //false

        // .isBlank() aparece a partir del JDK 11
        // indica si la cadena está en blanco o solo consiste en espacios en blanco, como por 
        //ejemplo si solo contiene espacios o tabulaciones o saltos de línea
        String texto4 = "   ";
        System.out.println(texto4.isEmpty()); //false
        System.out.println(texto4.isBlank()); //true

        // .charAt()
        //devuelve el caracter del índice pasado como parámetro
        System.out.println(texto1.charAt(3)); //e
        System.out.println(texto2.charAt(3)); //a

        // .indexOf()
        // devuelve el índice de la primera ocurrencia de la subcadena
        // si no encuentra la subcadena, devuelve -1
        System.out.println(texto1.indexOf("texto")); //-1 Texto está con mayúscula
        System.out.println(texto1.indexOf("Texto")); //10

        // .trim()
        // elimina los espacios de adelante y atrás
        System.out.println("   Buenas Noches   ");
        System.out.println("   Buenas Noches   ".trim());

        // .startsWith() .endsWith()
        // devuelve un booleano que indica si la cadena comienza o termina con la subcadena que pasamos como parámetro
        System.out.println(texto1.startsWith("hola")); //falso
        System.out.println(texto3.startsWith("hola")); //true
        System.out.println(texto1.endsWith("Texto")); //false
        System.out.println(texto1.endsWith("exto!")); //true

        // .substring()
        // extrae y devuelve una subcadena
        // con un parámetro trae la cadena desde la posición indicada como índice
        System.out.println(texto1.substring(10)); // Texto!
        // con dos parámetros extrae la cadena desde la posición del primer índice pasado como 
        //parámetro hasta el segundo índice pasado como parámetro pero sin incluirlo.
        System.out.println(texto1.substring(0, 6)); //Cadena

        // métodos para reemplazar
        // reemplazar un caracter por otro
        System.out.println(texto1.replace('e', 'i')); //Cadina di Tixto!
        // reemplazar una cadena por otra
        System.out.println(texto1.replace("Texto", "caracteres")); //Cadena de caracteres! 
        texto3 = "manzana, manzana, naranja";
        //reemplazar solo la primera vez que aparece la cadena
        System.out.println(texto3.replaceFirst("manzana", "banana")); // banana, manzana, naranja
        //reemplazar todas las veces que aparezca la cadena
        System.out.println(texto3.replaceAll("manzana", "banana")); // banana, banana, naranja
        System.out.println(texto3.replace("manzana", "banana")); // banana, banana, naranja
        //replaceAll() es mucho más potente que solo replace() porque permite buscar y reemplazar
        //patrones de expresiones regulares. Lo que se conoce como regex o regexp.
        //Una expresón regular es una secuencia de caracteres que definen un patrón de formato de
        //texto.
        String mensaje = "Mi número de teléfono es 011-4444-5555 y del trabajo 011-4444-3333";
        System.out.println(mensaje.replaceAll("\\d{3}-\\d{4}-\\d{4}", "HIDDEN INFORMATION"));

        // .repeat()
        // repite la cadena la cantidad de veces que le indiquemos como parámetro
        System.out.println(texto2.repeat(3)); // HolaHolaHola

        //caracteres de escape
        // son secuencias especiales de caracteres que se utilizan en cadenas de texto y literales 
        //para representar caracteres especiales que no se pueden representar directamente.
        //Los caracteres de escape comienzan con una barra invertida seguida del caracter que indica
        //de que tipo de escape estamos poniendo

        System.out.println("Hola\nMundo!"); //salto de línea
        System.out.println("Hola\tMundo!"); //tabulación
        System.out.println("\"Hola Mundo!\""); //comillas dobles
        System.out.println("\\Hola Mundo!\\"); //barra invertida


        

    }
}
