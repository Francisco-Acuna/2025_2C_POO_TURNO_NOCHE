package ar.org.centro8.java.curso.entidades.relaciones;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class EmpleadoAgregacion {
    /*
     * Las agregaciones son un tipo de relación más fuerte entre clases.
     * Son de las más utilizadas.
     * Las reconocemos con las palabras "tiene un/a".
     * Por ejemplo, en este caso, un empleado tiene un auto.
     */

    private int legajo;
    private String nombre;
    private String apellido;
    private Auto auto;

    //creamos un cosntructor sin el auto, ya que el auto es opcional.
    public EmpleadoAgregacion(int legajo, String nombre, String apellido) {
        this.legajo = legajo;
        this.nombre = nombre;
        this.apellido = apellido;
    }

    //con el setAuto() podemos asignar y cambiar el auto del empleado

}
