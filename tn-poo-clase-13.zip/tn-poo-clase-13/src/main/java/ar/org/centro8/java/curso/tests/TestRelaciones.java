package ar.org.centro8.java.curso.tests;

import java.util.List;

import ar.org.centro8.java.curso.entidades.relaciones.Auto;
import ar.org.centro8.java.curso.entidades.relaciones.ClienteMayorista;
import ar.org.centro8.java.curso.entidades.relaciones.ClienteMinorista;
import ar.org.centro8.java.curso.entidades.relaciones.Cuenta;
import ar.org.centro8.java.curso.entidades.relaciones.EmpleadoAgregacion;
import ar.org.centro8.java.curso.entidades.relaciones.EmpleadoAsociacionSimple;
import ar.org.centro8.java.curso.entidades.relaciones.EmpleadoComposicion;

public class TestRelaciones {
    public static void main(String[] args) {
        System.out.println("** Test de la clase Cuenta **");

        Cuenta cuenta1 = new Cuenta(1, "Pesos argentinos");
        System.out.println(cuenta1);
        cuenta1.depositar(100000);
        cuenta1.debitar(10000);
        System.out.println(cuenta1.getSaldo()); //90.000

        Cuenta cuenta2 = new Cuenta(2, "Dólares");
        System.out.println(cuenta2);
        cuenta2.depositar(12000);
        cuenta2.debitar(10000);
        cuenta2.depositar(5000);
        cuenta2.debitar(10000); //saldos insuficientes
        System.out.println(cuenta2.getSaldo()); //7.000

        System.out.println("\n** Test de la clase clienteMinorista **");

        ClienteMinorista cliente1 = new ClienteMinorista(1, "Jose", "Perez", cuenta1);
        System.out.println(cliente1);
        System.out.println(cliente1.getCuenta());
        // cliente1.depositar(10000); error, el método depositar no pertene a la clase ClienteMinorista
        //es un método de la clase Cuenta
        cliente1.getCuenta().depositar(10000);
        System.out.println(cliente1.getCuenta().getSaldo());

        //creamos un apuntador
        //un apuntador es una referencia, no ocupa más lugar de memoria
        Cuenta cta1 = cliente1.getCuenta();
        cta1.depositar(50000);
        System.out.println(cta1.getSaldo()); //150000
        cta1.debitar(10000);
        System.out.println(cliente1);

        System.out.println("\n** Test de ClienteMayorista **");
        ClienteMayorista cliente2 = new ClienteMayorista(12, "Caleidoscopio", "Jujuy 132");
        System.out.println(cliente2);
        //creamos un apuntador para facilitar el manejo de las cuentas
        List<Cuenta> cuentas2 = cliente2.getCuentas();

        //con el método .add() agregamos cuentas a la lista
        cuentas2.add(cuenta2); //agregamos la cuenta2 a la lista de cuentas del cliente2
        cuentas2.add(new Cuenta(3, "Libras esterlinas"));
        cuentas2.add(new Cuenta(4, "Reales"));

        //con .get() obtengo la cuenta de la lista según el índice indicado en el parámetro
        System.out.println(cuentas2.get(0)); //se muestra la cuenta de índice cero de la lista
        //en este caso es la cuenta2
        cuentas2.get(0).depositar(10000);        
        System.out.println(cliente2);

        ///////////////////////////////////////////////////////////////////////////
        
        System.out.println("\n** Test de la clase EmpleadoAsociacionSimple **");
        Auto auto1 = new Auto("Citröen", "C4", "Rojo");
        EmpleadoAsociacionSimple empleado1 = new EmpleadoAsociacionSimple(1, "Arnold", "Schaurseneguer");
        System.out.println(empleado1);
        empleado1.usarAuto(auto1);

        System.out.println("\n** Test de la clase EmpleadoAgregacion **");
        EmpleadoAgregacion empleado2 = new EmpleadoAgregacion(2, "Cosme", "Fulanito");
        System.out.println(empleado2);
        empleado2.setAuto(auto1);
        System.out.println(empleado2);

        System.out.println("\n** Test de la clase EmpleadoComposicion **");
        EmpleadoComposicion empleado3 = new EmpleadoComposicion(3, "Anibal", "Troilo", auto1);
        System.out.println(empleado3);

        EmpleadoComposicion empleado4 = new EmpleadoComposicion(4, "Roberto", "Goyeneche", 
                                                                "Renault", "9", "Gris");
        System.out.println(empleado4);

    }
}
