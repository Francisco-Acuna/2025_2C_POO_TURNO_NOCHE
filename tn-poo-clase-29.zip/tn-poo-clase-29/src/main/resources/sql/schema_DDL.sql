DROP DATABASE IF EXISTS colegio_nocturno;
CREATE DATABASE colegio_nocturno;
USE colegio_nocturno;

DROP TABLE IF EXISTS cursos;
DROP TABLE IF EXISTS alumnos;

CREATE TABLE cursos(
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(100) NOT NULL CHECK(LENGTH(titulo)>=3),
    profesor VARCHAR(100) NOT NULL CHECK(LENGTH(profesor)>=3),
    dia ENUM('LUNES', 'MARTES', 'MIÉRCOLES', 'JUEVES', 'VIERNES') NOT NULL,
    turno ENUM('MAÑANA', 'TARDE', 'NOCHE') NOT NULL,
    activo BOOLEAN DEFAULT true    
);

CREATE TABLE alumnos(
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL CHECK(LENGTH(nombre)>=3),
    apellido VARCHAR(100) NOT NULL CHECK(LENGTH(apellido)>=3),
    edad INT NOT NULL CHECK(edad>=18 AND edad<=100),
    id_curso INT NOT NULL,
    activo BOOLEAN DEFAULT true
);