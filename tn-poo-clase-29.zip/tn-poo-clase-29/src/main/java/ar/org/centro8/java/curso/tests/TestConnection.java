package ar.org.centro8.java.curso.tests;

import java.io.InputStream;
import java.util.Properties;

import com.zaxxer.hikari.HikariConfig;

/**
 * Clase de prueba de conexión a la DB para validar la configuración de HikariCP
 */
public class TestConnection {
    public static void main(String[] args) {

        Properties props = new Properties();
        //creamos un objeto de Properties para cargar el fichero de configuración
        try (InputStream in = TestConnection.class //obtenemos el objeto Class de esta clase
                                .getClassLoader() // obtenemos el ClassLoader que es el encargado
                                //de cargar clases y recursos en tiempo de ejecución
                                .getResourceAsStream("application.properties")) {
                                    //busca el archivo que se llame application.properties y lo 
                                    //devuelve como un flujo de bytes.
            if(in == null){
                System.err.println("No se encontró el archivo application.properties");
                return;
            }
            props.load(in);            
        } catch (Exception e) {
            System.err.println("Error cargando las properties: " + e.getMessage());
            return;
        }

        //creamos la configuración del pool
        HikariConfig config = new HikariConfig();

        //leemos la URL de la DB
        config.setJdbcUrl(props.getProperty("spring.datasource.url"));

        

    }
}
