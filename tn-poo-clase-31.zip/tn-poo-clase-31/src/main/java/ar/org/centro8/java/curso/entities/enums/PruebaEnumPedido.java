package ar.org.centro8.java.curso.entities.enums;

public enum PruebaEnumPedido {
    PENDIENTE("Pedido pendiente de envío."),
    EN_PROCESO("Pedido en proceso de preparación."),
    ENTREGADO("Pedido entregado al cliente");

    private final String descripcion;
    
    private PruebaEnumPedido(String descripcion){
        this.descripcion=descripcion;
    }

    @Override
    public String toString(){
        return  name() + " -> " + descripcion;
    }
}
