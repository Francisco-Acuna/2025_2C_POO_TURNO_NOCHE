package ar.org.centro8.java.curso.entities.enums;

public enum Dia {
    LUNES,
    MARTES,
    MIERCOLES,
    JUEVES,
    VIERNES;
}

/*
 * Un enum es un tipo de clase en Java que define un conjunto fijo de elementos constantes.
 * Se utiliza para representar valores limitados y conocidos de antemano.
 * Sería como una lista fija de opciones. En vez de pasar el texto "LUNES", se utiliza Dia.LUNES
 * y Java impide poner cualquier otro valor que no exista en esa lista.
 * Cada valor dentro del enum es una constante que represneta una instancia de la clase Enum, en
 * este caso, son objetos de la clase Dia que es un Enum.
 * Estos objetos pueden poseer atributos, para ello debe crearse un constructor privado que le
 * permita asignar el valor como estado.
 * Los Enums implementan Comparable automáticamente.
 * No pueden extender de otras clases pero pueden implementar interfaces.
 * Se puede sobreescribir el método toString() para que muestre un texto distinto al del name()
 */
