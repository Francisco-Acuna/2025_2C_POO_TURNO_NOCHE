package ar.org.centro8.java.curso.tests;

import ar.org.centro8.java.curso.entities.enums.PruebaEnumPedido;

public class TestPruebaEnums {
    public static void main(String[] args) {

        System.out.println(PruebaEnumPedido.PENDIENTE);
        System.out.println(PruebaEnumPedido.EN_PROCESO);
        System.out.println(PruebaEnumPedido.ENTREGADO);
    
    }
}
