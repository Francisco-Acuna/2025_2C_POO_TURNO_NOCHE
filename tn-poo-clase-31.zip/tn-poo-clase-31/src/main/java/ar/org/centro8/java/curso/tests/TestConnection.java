package ar.org.centro8.java.curso.tests;

import java.io.InputStream;
import java.sql.Connection;
import java.util.Properties;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

/**
 * Clase de prueba de conexión a la DB para validar la configuración de HikariCP
 */
public class TestConnection {
    public static void main(String[] args) {

        Properties props = new Properties();
        //creamos un objeto de Properties para cargar el fichero de configuración
        try (InputStream in = TestConnection.class //obtenemos el objeto Class de esta clase
                                .getClassLoader() // obtenemos el ClassLoader que es el encargado
                                //de cargar clases y recursos en tiempo de ejecución
                                .getResourceAsStream("application.properties")) {
                                    //busca el archivo que se llame application.properties y lo 
                                    //devuelve como un flujo de bytes.
            if(in == null){
                System.err.println("No se encontró el archivo application.properties");
                return;
            }
            props.load(in);            
        } catch (Exception e) {
            System.err.println("Error cargando las properties: " + e.getMessage());
            return;
        }

        //creamos la configuración del pool
        HikariConfig config = new HikariConfig();

        //leemos la URL de la DB
        config.setJdbcUrl(props.getProperty("spring.datasource.url"));
        //guardamos el usuario
        config.setUsername(props.getProperty("spring.datasource.username"));
        //guardamos la contraseña
        config.setPassword(props.getProperty("spring.datasource.password"));

        //creamos el datasource con el pool de conexiones y probamos la conexión
        try (HikariDataSource ds = new HikariDataSource(config);
                Connection conn = ds.getConnection()) { //obtenemos la conexión desde el datasource
            if(conn.isValid(3)){
                System.out.println("Conexión exitosa a: " + conn.getMetaData().getURL());
                //getMetadata() obtiene la información sobre la conexión activa
                //getURL() retorna la URL de la conexión.
                //La imprimimos para comprobar a qué base estamos conectado
            }
        } catch (Exception e) {
            System.err.println("No se pudo conectar: " + e.getMessage());
        }

        

    }
}
