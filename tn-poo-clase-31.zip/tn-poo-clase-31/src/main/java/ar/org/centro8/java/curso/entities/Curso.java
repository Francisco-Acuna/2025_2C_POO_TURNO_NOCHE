package ar.org.centro8.java.curso.entities;

import ar.org.centro8.java.curso.entities.enums.Dia;
import ar.org.centro8.java.curso.entities.enums.Turno;

public class Curso {
    private int id;
    private String titulo;
    private String profesor;
    private Dia dia;
    private Turno turno;
    private boolean activo;
}
