package ar.org.centro8.java.curso.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.config.ListFactoryBean;

import ar.org.centro8.java.curso.entities.Alumno;

public interface IAlumnoDAO {
    //todos estos métodos pueden lanzar una excepción, del tipo SQLException, que es una checked exception
    
    /**
     * Método para crear un alumno. Recibe como parámetro un objeto del tipo Alumno y guarda el
     * registro en la base de datos. 
     * @param alumno -> recibe un objeto de alumno al que luego le setea el id autogenerado por la base
     * @throws SQLException
     */
    void create (Alumno alumno) throws SQLException;

    /**
     * Método que busca un alumno por su id. Recibe como parámetro el id del alumno a buscar y lo
     * retorna como un objeto de la clase Alumno.
     * @param id
     * @return
     * @throws SQLException
     */
    Alumno findById(int id) throws SQLException;

    /**
     * Método para obtener el listado de todos los alumnos. No recibe parámetros y devuelve una
     * lista de todos los registros de alumnos en la base de datos.
     * @return
     * @throws SQLException
     */
    List<Alumno> findAll() throws SQLException;  

    /**
     * Método para actualizar un alumno en la base de datos. Recibe como parámetro un objeto del tipo
     * Alumno y actualiza sus datos en el registro de la base de datos.
     * @param alumno
     * @return
     * @throws SQLException
     */
    int update(Alumno alumno) throws SQLException;

    /**
     * Método para eliminar un alumno en la base de datos. Recibe como parámetro un id que identifica
     * al alumno. Devuelve un entero indicando si se pudo eliminar el registro.
     * @param id
     * @return
     * @throws SQLException
     */
    int delete(int id) throws SQLException;

    /**
     * Método que busca alumnos por su id de curso. Recibe como parámetro el id del curso y devuelve
     * una lista con todos los registros de los alumnos.
     * @param idCurso
     * @return
     * @throws SQLException
     */
    List<Alumno> findByCurso(int idCurso) throws SQLException;
}
