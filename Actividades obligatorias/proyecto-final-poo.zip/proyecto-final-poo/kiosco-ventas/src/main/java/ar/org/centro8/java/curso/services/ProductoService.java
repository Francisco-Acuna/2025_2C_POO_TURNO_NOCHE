package ar.org.centro8.java.curso.services;

import org.springframework.stereotype.Service;

import ar.org.centro8.java.curso.model.entity.Producto;
import ar.org.centro8.java.curso.model.repository.ProductoRepository;

import java.util.List;

@Service
public class ProductoService {
    private final ProductoRepository repo;

    public ProductoService(ProductoRepository repo) {
        this.repo = repo;
    }

    public List<Producto> listar() {
        
    }

    public Producto buscar(int id) {
        
    }

    public void guardar(Producto p) {
        
    }

    public void actualizar(Producto p) {
        
    }

    public void eliminar(int id) {
       
    }
}
