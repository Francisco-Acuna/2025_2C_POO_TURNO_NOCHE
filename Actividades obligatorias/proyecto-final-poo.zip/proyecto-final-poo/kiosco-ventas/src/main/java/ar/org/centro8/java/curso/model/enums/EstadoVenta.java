package ar.org.centro8.java.curso.model.enums;

public enum EstadoVenta {
    PENDIENTE, PAGADA, ANULADA
}
