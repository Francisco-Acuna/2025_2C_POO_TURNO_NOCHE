public class Clase01 {
    public static void main(String[] args) {
        /*
         * Instituto: Centro de Formación Profesional N°8 - SMATA
         * Curso: Programación Orientada a Objetos
         * Lenguaje principal: Java
         * Cursada: Lunes, miércoles y viernes de 19 a 22.20hs.
         * Profesor: Francisco Acuña
         * Email: franciscoacuna.centro8@gmail.com
         * Repositorio: https://github.com/Francisco-Acuna/2025_2C_POO_TURNO_NOCHE
         * Softwares necesarios:
         *  - JDK 21 -> https://www.oracle.com/java/technologies/downloads/#java21
         *  - Visual Studio Code -> https://code.visualstudio.com/
         *  - MySQL y Workbench -> https://dev.mysql.com/downloads/installer/
         *  - Extensión de VSC -> Extension Pack for Java (by Microsoft)
         */

        // comentarios en línea
        
        /*
         * comentarios
         * en
         * bloque
         */

        /**
         * Comentarios
         * del tipo
         * JavaDoc
         */

        // etiquetas en los comentarios

        // TODO: indica tareas pendientes a implementar o finalizar

        // FIXME: señalan errores o problemas que deben ser corregidos

        //estas palabras no son parte del lenguaje Java como tal, sino convenciones que se usan
        //dentro de los comentarios. Muchos editores e IDEs las reconocen y resaltan automáticamente
        //para facilitar la colaboración y el seguimiento de tareas en el código.

        //instalar la extensión TODO TREE de Gruntfuggly

        //impresión por consola
        System.out.println("Hola Mundo!");
        //sout + tab -> atajo para impresión por consola
        //ctrl + shift + k -> elimina la línea

        //declaración de variable:
        int variable; //declaración de variable con tipo de dato e identificador
        variable = 10; //asignación de valor a la variable
        int variable2 = 10; //declaración y asignación de valor en línea
        int variable3=10, variable4=20, variable5=30; //declaración y asignación múltiple en línea



    } //fin del método main
} //fin de la clase
