package ar.org.centro8.java.curso.tests;

public class TestEncapsulamiento {

}
