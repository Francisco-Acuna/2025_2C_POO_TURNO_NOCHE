package ar.org.centro8.java.curso.excepciones;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class NoHayMasPasajesException extends Exception{
    //aplicamos una excepción para validar una regla de negocio.
    //con esta clase vamos a crear una Exception que se va a lanzar en el caso de que 
    //no existan los pasajes requeridos para la venta.

    //para que la clase sea realmente una excepción, debe extender de Exception
    //al extender directamente de Exception es una checked exception

    private String nombreVuelo;
    private int cantidadPasajes;
    private int cantidadNoValidaPasajes;

    //modificamos el toString() para tener el mensaje que recibirá el usuario al momento de 
    //lanzarse esta excepción
    @Override
    public String toString(){
        return "El vuelo " + nombreVuelo + " no tiene " + cantidadNoValidaPasajes + " solo tiene "
                + cantidadPasajes + " pasajes disponibles.";
    }

}
