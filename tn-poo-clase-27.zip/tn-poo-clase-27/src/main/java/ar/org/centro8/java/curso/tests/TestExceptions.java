package ar.org.centro8.java.curso.tests;

import java.io.File;
import java.io.FileInputStream;

import ar.org.centro8.java.curso.excepciones.GeneradorDeExcepciones;
import ar.org.centro8.java.curso.excepciones.Vuelo;

public class TestExceptions {
    public static void main(String[] args) {

        //la siguiente sentencia dará un error que detendrá la JVM
        // System.out.println(10/0);
        // System.out.println("Esta línea no se ejecuta");

        //Las excepciones son un corte abrupto del sistema que frena la ejecución con una
        //salida de error.

        //manejo de excepciones
        //estructura try-catch-finally -> mecanismo para el manejo de excepciones

        try { //obligatorio
            /*
             * En este bloque se colocan todas las sentencias que puedan lanzar una Exception.
             * Si no se produce ningún error, el bloque se ejecuta normalmente y salta al bloque
             * finally (si es que existe).
             * Si se lanza una Exception, la ejecución del bloque try se detiene y se transfiere
             * el control al bloque del catch.
             */
        } catch (Exception e) { //obligatorio la mayoría de las veces
            /*
             * En este bloque se definen las acciones a realizar cuando se produce una Exception.
             * Se captura la excepción mediante un objeto del tipo Exception que contiene información
             * del error.
             * El programa continúa su ejecución después de este bloque, sin detenerse abruptamente.
             * Salta al bloque finally, si es que existe.
             */
        } finally { // opcional
            /*
             * Este bloque se ejecuta siempre, independientemente de que se haya lanzado o no una
             * Exception.
             * Se utiliza principalmente para liberar recursos o realizar tareas de limpieza, como
             * cerrar archivos, conexiones o autocompletado de código.
             * Las variables declaradas dentro de los bloques try y catch no tienen alcance (scope)
             * en este bloque. 
             */
        }

        //estas sentencias se ejecutan siempre
        //el programa finaliza normalmente.

        //ejemplo
        try {
            System.out.println(10/0);
            System.out.println("Esta línea no se ejecuta si se produce una excepción.");
        } catch (Exception e) {
            System.out.println("Mensaje del bloque catch: Ocurrió un error.");
            // System.out.println(e); //imprimimos el objeto del error
            // System.out.println(e.getMessage()); //mensaje corto con la descripción
            // System.out.println(e.getLocalizedMessage()); //igual que el anterior pero muestra un 
            //mensaje traducido según la configuración regional si es que fue sobreescrita.
            // System.out.println(e.getCause()); //retorna la causa (otra exception)que provocó la excepción actual
            e.printStackTrace(); //imprime la traza del error, lo que facilita la depuración al 
            //mostrar la secuencia de llamadas que conujeron a la excepción.    
        } finally {
            System.out.println("Mensaje del bloque finally: este bloque se ejecutará siempre.");
        }

        System.out.println("Mensaje fuera del bloque try-catch-finally: Esta sentencia se ejecuta sin problemas.");
        System.out.println("El programa finaliza normalmente.");

        /*
         * Throwable es la clase raíz de las excepciones. Hereda de Object. Esta clase representa
         * todo aquello que puede lanzarse (throw) y que puede interrumpir el flujo normal del programa.
         * Throwable tiene dos subclases principales: Error y Exception
         * Error:
         *      - Representa errores graves, generalmente relacionados con la JVM o fallos críticos de
         * hardware, como por ejemplo OutOfMemory, StackOverFlowError, etc.
         *      - Estos errores no están diseñados para ser capturados ni manejados, ya que indican 
         * condiciones de las que la aplicación en la mayoría de los casos, no puede recuperarse.
         *      - Dentro de Error, se encuentra AssertionError, que se lanza cuando falla una aserción
         * (assert). Las aserciones se utilizan principalmente para pruebas y diagnóstico.
         * 
         * Exception:
         *      - Representa condiciones anómalas que pueden ocurrir durante la ejecución del programa, y
         * que en la mayoría de los casos, pueden ser manejadas o recuperadas.
         *      - Dentro de Exception existen dos tipos:
         *              - checked exceptions: son aquellas que el compilador obliga a capturar o declarar
         * en la firma de los métodos. Estas excepciones heredan directamente de Exception.
         *              - unchecked exceptions: son aquellas en las que no es obligatorio capturar o declarar,
         * ya que generalmente indican errores de lógica o condiciones inesperadas. Estas excepciones heredan
         * de RuntimeException.
         * 
         * En definitiva:
         * Throwable: raíz de todos los objetos "lanzables" de Java.
         * Error: errores graves que no deben (o no se pueden) manejar.
         * Exception: condiciones de error que se pueden manejar, divididas en:
         *      checked exception: obligatorias de capturar o declarar.
         *      unchecked exception: no obligatorias de capturar, usadas en errores de programación.
         */

        //las excepciones del tipo checked exception estamos obligados a controlarlas, por ejemplo:
        // FileInputStream in = new FileInputStream(new File("texto.txt"));

        try {
            FileInputStream in = new FileInputStream(new File("texto.txt"));
        } catch (Exception e) {
            System.out.println(e);
        }

        //cualquiera de estas excepciones del tipo unchecked pueden detener el programa
        //por eso las vamos a capturar en un bloque try-catch
        try {
            // GeneradorDeExcepciones.generar(); //ArrayIndexOutOfBoundsException
            // GeneradorDeExcepciones.generar("hola", 10); //StringIndexOutOfBoundsException
            // GeneradorDeExcepciones.generar("10f"); //NumberFormatException
            GeneradorDeExcepciones.generar(true); //ArithmeticException
        } catch (Exception e) {
            System.out.println(e);
        }

        //captura personalizada de excepciones
        //vamos a tener varios catch para personalizar la salida de acuerdo al tipo de error.
        //La excepción va ir viendo en cuál bloque catch entrar, como si fuese una estructura
        //del tipo switch case. Las excepciones padre deben ir al final.
        try {
            // GeneradorDeExcepciones.generar(true);
            // GeneradorDeExcepciones.generar("10f");
            // GeneradorDeExcepciones.generar();
            GeneradorDeExcepciones.generar("hola", 10);
        } catch (ArithmeticException e) { System.out.println("Error de división por cero."); 
        } catch (NumberFormatException e) { System.out.println("Error de formato de número incorrecto.");
        // } catch (ArrayIndexOutOfBoundsException e) {System.out.println("Índice fuera de rango.");
        // } catch (StringIndexOutOfBoundsException e) { System.out.println("Índice fuera de rango.");
        //multicatch
        // } catch (ArrayIndexOutOfBoundsException | StringIndexOutOfBoundsException e) { System.out.println("Índice fuera de rango.");
        } catch (IndexOutOfBoundsException e) { System.out.println("Índice fuera de rango");
        } catch (Exception e) { System.out.println("Ocurrió un error inesperado");
        }
        //sintaxis de multicatch aparece a partir del JDK7 para capturar varios tipos de excepciones
        //en un solo bloque, lo que simplifica y reduce la redundancia de código cuando la acción a
        //tomar es la misma. El operador | no es el or tradicional, es un operador que sirve para
        //separar los distintos tipos de excepciones.

        /////////////////////////////////////////////////////////////////////
        System.out.println("\n$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");

        Vuelo vuelo1 = new Vuelo("AER123", 100);

        // vuelo1.venderPasajes(10); esto da error porque debo capturar o propagar la excepción

        try {
            vuelo1.venderPasajes(10);
            vuelo1.venderPasajes(40);
            vuelo1.venderPasajes(20);
            vuelo1.venderPasajes(20);
            vuelo1.venderPasajes(30);
            vuelo1.venderPasajes(10);
        } catch (Exception e) {
            System.out.println(e);
        }

        System.out.println(vuelo1);

        /////////////////////////////////////////////////////////////////////
        System.out.println("\n$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
        FileInputStream in = null;
        try {
            in = new FileInputStream(new File("texto.txt"));
            in.read();
            in.close();
        } catch (Exception e) {
            // in.close();
            try {
                in.close();
            } catch (Exception ee) {
                System.out.println(ee);
            }
        }

        //a partir del JDK7 aparece el try-with-resources
        //simplifica el manejo y liberación de recursos (como archivos, conexiones a BD, sockets. etc.)
        //que deban cerrarse luego de utilizarse.
        //El recurso que se utilice para cerrarse debe implementar la interfaz Closeable o AutoCloseable
        //Java se encarga de cerrar estos recursos si o sí.
        




    }
}
