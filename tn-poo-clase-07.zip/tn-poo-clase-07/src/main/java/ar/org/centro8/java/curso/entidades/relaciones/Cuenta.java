package ar.org.centro8.java.curso.entidades.relaciones;

public class Cuenta {
    private int nro;
    private String moneda;
    private float saldo;

    public void depositar(float monto){
        saldo += monto;
    }
    
}
