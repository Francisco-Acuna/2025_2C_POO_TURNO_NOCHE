package ar.org.centro8.java.curso.entidades.colecciones;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@AllArgsConstructor
@EqualsAndHashCode
public class Auto implements Comparable<Auto>{
    private String marca;
    private String modelo;
    private String color;

    @Override
    public int compareTo(Auto auto2) {
        String autoOriginal = this.getMarca() + ", " + this.getModelo() + ", " + this.getColor();
        String autoParametro = auto2.getMarca() + ", " + auto2.getModelo() + ", " + auto2.getColor();
        return autoOriginal.compareTo(autoParametro);
        //utilizamos el método compareTo() de la clase String
    }

    /*
     * El método compareTo() se utiliza para reflejar el ordenamiento natural de una clase.
     * El ordenamiento natural significa el orden de clasificación que se aplica al objeto. Por 
     * ejemplo el ordenamiento alfabético para cadenas o numérico para enteros.
     * Este método compara al objeto de la clase con el objeto que ingresa como parámetro.
     * Devuelve:
     *  0 si son iguales
     *  -1 si el objeto de la clase es menor que el que entró como parámetro
     *  1 si el objeto de la clase es mayor que el que entró como parámetro.
     */


}
